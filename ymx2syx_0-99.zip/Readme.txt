==============================================================================
YMX2SYX v0.99
Written by Damian Grove
May 28, 2017
==============================================================================

If you've ever wanted to convert sounds from Sega Genesis games over to a
Yamaha FM synthesizer, this tool does just that! The Genesis uses a YM2612 FM
synthesis chip which makes the voices used in Genesis games compatible with
many Yamaha DX/TX synthesizers.

Compatible FM synthesizers are as follows:

  * DX11
  * DX21
  * DX27
  * DX27S
  * DX100
  * TX81Z


################
# Requirements #
################

You will need the following to use YMX2SYX:

  * Microsoft Windows
  * Java 7


###################
# Release History #
###################

05/28/2017
Version 0.99

Initial release!


########################
# Types of SysEx Files #
########################

YMX2SYX can create three types of SysEx files: VMEM, VCED, and automated VCED.

The VMEM files are the standard bank files that are normally imported and
exported with DX/TX synthesizers. Voices will load starting at the first voice
in the voice bank on the unit.

A standard VCED (Voice Edit) file will contain a single voice that, when
uploaded to the synthesizer, will overwrite edit parameters for the voice
currently selected on the unit. Since voice edit data is temporary, it will
only be active as long as the voice selection doesn't change.

Automated VCED files allow for multiple VCED-formatted voices. Each voice will
get stored into the VMEM block for the currently selected voice on the unit,
followed by automated navigation to the next voice where the process will
repeat again, until all voices have been stored.

Which format is appropriate depends on each individual's needs. VMEM files are
more compact and upload to the hardware faster, but larger SysEx files in this
format will also require a larger MIDI buffer. VCED-formatted data is less
demanding on MIDI buffers, but are roughly 33% larger in size and take a bit
longer to upload.


#################
# Using YMX2SYX #
#################

To use this tool, a command line input is necessary. Usage is as follows:

ymx2syx.exe [Conversion] [in.ymx] [out.syx] [Options]

There are two types of conversion arguments that can be specified. They are as
follows:

  * -vced
  * -vmem

Depending on additional options specified in the command, the VCED SysEx file
will either be standard or automated.

Next, the input and output files will need to be specified. The input file is
the path/name of the source YMX file to do the conversion on. The output file
is the path/name of the destination SysEx file to be created to hold the
converted data.

After the conversion argument, the input file, and the output file, there are
some optional arguments that can be used. They are as follows:

  * -autostore
  * -channel [x]
  * -maxvoices [x]
  * -voice [x]

Use the '-autostore' argument to force an automated VCED format, as opposed to
the standard VCED format. This is useful if it is desired for the voice to be
stored after it is uploaded to the unit.

The '-channel' argument will allow a specific channel to be specified for the
conversion. Otherwise, channel 1 will be used. Channel 'x' can be any number
from 1 to 16.

The '-maxvoices' argument will cause the conversion to stop after 'x' number
of voices have been processed. This can also be used to resolve an issue
present in YMX banks generated from SOME (Sonic One Music Editor) where the
voice count is incorrect.

Specifying the '-voice' argument will create a SysEx file that excludes all
voices except voice 'x', a number between 0 and 127.

Examples of usage combinations are as follows:

  * ymx2syx.exe -vmem Saxman.ymx Saxman.syx -channel 15
  * ymx2syx.exe -vced MyBank.ymx MyBank.syx -maxvoices 4
  * ymx2syx.exe -vced Input.ymx Output.syx -voice 6 -autostore


###########
# Contact #
###########

If you have any questions, feel free to send an e-mail to 'ymtx81z' at Yahoo.
